document.getElementById("urlInput").addEventListener("input", function () {
    const urlInput = this;
    const urlRegex = /^(https?:\/\/)[^\s]+\.[^\s]+$/;

    if (urlRegex.test(urlInput.value)) {
        urlInput.classList.add("valid");
        urlInput.classList.remove("invalid");
    } else {
        urlInput.classList.add("invalid");
        urlInput.classList.remove("valid");
    }
});

document.getElementById("emailInput").addEventListener("input", function () {
    const emailInput = this;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailRegex.test(emailInput.value)) {
        emailInput.classList.add("valid");
        emailInput.classList.remove("invalid");
    } else {
        emailInput.classList.add("invalid");
        emailInput.classList.remove("valid");
    }
});